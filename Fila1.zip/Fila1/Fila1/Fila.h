//
//  Fila.h
//  Fila1
//
//  Created by Victor Lisboa on 06/02/15.
//  Copyright (c) 2015 Victor Lisboa. All rights reserved.
//

#ifndef Fila1_Fila_h
#define Fila1_Fila_h
#import <Foundation/Foundation.h>

@interface Fila:NSObject

-(void) enfileira:(NSObject *)objeto;
-(void)desenfileira;
-(NSObject *)ler;
-(BOOL)vazio;
-(void) imprime;

@end

#endif
