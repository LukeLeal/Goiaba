//
//  main.m
//  Fila1
//
//  Created by Victor Lisboa on 06/02/15.
//  Copyright (c) 2015 Victor Lisboa. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Fila.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        Fila *f = [[Fila alloc] init];
        
        [f enfileira:@"F"];
        [f enfileira:@"I"];
        [f enfileira:@"L"];
        [f enfileira:@"A"];
        [f imprime];
        }
    return 0;
}
