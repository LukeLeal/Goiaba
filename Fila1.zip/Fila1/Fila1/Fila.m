//
//  Fila.m
//  Fila1
//
//  Created by Victor Lisboa on 06/02/15.
//  Copyright (c) 2015 Victor Lisboa. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Fila.h"

@interface Fila()
@property NSMutableArray *dados;
@end

@implementation Fila
-(instancetype)init;
{
    _dados = [[NSMutableArray alloc]init];
    return self;
}
-(void) enfileira:(NSObject *)objeto;
{
    [_dados addObject:objeto];
}
-(void)desenfileira;
{
    //[_dados removeObjectAtIndex:0];
    if (![self vazio]) {
        [_dados removeObjectAtIndex:0];
    }
}
-(NSObject *)ler;
{
    return [_dados firstObject];
}
-(BOOL)vazio;
{
    return _dados.count == 0;
//    if (_dados.count==0){
//        return YES;
//    }
//    else{
//        return NO;
//    }
}
-(void) imprime;
{
    NSString *saida =@"";
    for (int i = 0; i<_dados.count; i++) {
        saida = [saida stringByAppendingString:[NSString stringWithFormat:@" %@ ", _dados[i]]];
    }
    NSLog(@"%@", saida);
}
@end